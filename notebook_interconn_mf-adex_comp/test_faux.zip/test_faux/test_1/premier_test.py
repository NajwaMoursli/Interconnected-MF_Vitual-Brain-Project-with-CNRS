import numpy as np
import sys
import matplotlib.pylab as plt
import matplotlib as mpl
#sys.path.append('mean_field_adapt')
#from transfer_functions.tf_simulation import single_experiment_2,single_experiment
from scipy.interpolate import interp2d
import math

x=np.load('x_trace_2pop_delay_qe.npy')
F=np.load('TF_trace_2pop_delay_qe.npy')

x_transp=np.transpose(x)
TF_transp=np.transpose(F)
ve1=x_transp[0]#[1000:] # remove first 10000 elements
vi1=x_transp[2]
vi2=x_transp[3]
ve2=x_transp[1]#[1000:]
#w1=x_transp[20]
TF1=TF_transp[0]
TF2=TF_transp[1]
TF3=TF_transp[2]
#TF=TF1[0:5]
q=np.linspace(0.5,1.5,4000)
d=np.linspace(1,5,4000)
f=interp2d(q,d,TF2, kind='linear')
q_coords=np.arange(min(q),max(q)+1)
d_coords=np.arange(min(d),max(d)+1)
V=f(q_coords,d_coords)

x,y=np.meshgrid(q_coords,d_coords)

fig2=plt.figure(figsize=(20,12))
ax21=fig2.add_subplot(221)

im21=ax21.contourf(x,y,V,cmap='jet',extend='max',levels=np.arange(0,90,5)) # extent=[min(q),max(q),max(d),min(d)] levels=np.arange(-80,250,10) ,levels=np.arange(0,90,5)
#levels=np.arange(8,17,1)

ax21.set_ylabel("Delay (ms)")
#ax21.invert_xaxis()
#ax21.invert_yaxis()
ax21.set_xlabel("Qe (nS)")
ax21.set_yticks(np.linspace(1,5,5))
ax21.set_xticks(np.linspace(0.5,1.5,5))
ax21.set_title("Excitatory Firing rate for E1 (Hz)")
cbar=fig2.colorbar(im21, ax=ax21)
cbar.set_label('$\\nu_e1$ (Hz)')
plt.show()


